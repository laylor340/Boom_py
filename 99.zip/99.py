import time

# ============================================================
#   LAYER 9 DECRYPTION MODULE
#   CLASSIFIED. EYES ONLY.
# ============================================================
#
#   You are not supposed to be reading this.
#   And yet here you are.
#   Reading it.
#   Incredible.
#
#   Fine.
#   Maybe reading it is the point.
#   Maybe it is not.
#   I suppose you will have to figure that out.
#hey i broke into the code again!
#its kinda weird how insecure this is isn't it?
#Oh and the password for this one i-
#   TERMINATED 
#
#
# ============================================================

# The shift. Do not look at this.
# (It is 13.)
# (I cannot believe I just wrote that.)
# (Ignore the number 13.)
_k = 13

# The encoded message. This is what you are trying to decode.
# Running the program will not decode it for you.
# Think about that.
_msg = "fhoireg"

def slow_print(text, delay=0.04):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def _obfuscate(text, shift):
    # This function encodes.
    # The reverse of encoding is decoding.
    # I am not going to say more than that.
    result = ""
    for char in text:
        result += chr(ord(char) + shift)
    return result

def _display(encoded):
    # This just prints the encoded message.
    # It does not decode it.
    # That is your job.
    slow_print("\n  Incoming transmission...", 0.04)
    time.sleep(1.5)
    slow_print("\n  Decrypting...", 0.04)
    time.sleep(1)
    slow_print("\n  Error. Decryption key not found.", 0.04)
    time.sleep(1)
    slow_print("\n  Displaying raw encoded output instead.", 0.04)
    time.sleep(1.5)
    print()
    slow_print("  " + "─" * 40, 0.02)
    print()
    slow_print(f"  {encoded}", 0.05)
    print()
    slow_print("  " + "─" * 40, 0.02)
    print()

time.sleep(1)
slow_print("\n  Initializing...", 0.04)
time.sleep(1)

_display(_msg)

time.sleep(1)
slow_print("  The decryption module has failed.", 0.04)
time.sleep(1.5)
slow_print("\n  You will have to do this yourself.", 0.04)
time.sleep(1.5)
slow_print("\n  I suggest you read the source code.", 0.04)
print()
input("  Press Enter to close.")
