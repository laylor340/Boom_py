import time

data = (
    "QWIFNRDCKAONWETBMXZPLQRSVYHDKWOFPVAUSIE"
    "YCXZMBLQRTVHDJWKSNPFAOYUICGEBRTXZLMVHQW"
    "PSNDKAOFRTYUIBCXZMLVHQWEJSNPFAORYUICGBX"
    "ZMLVHQWEJKSNPFAORYUICGBXZMLVHQWEJKSNPFA"
    "ORYUICGBXZMLVHQWEJKSNPFAORYUICGBXZMLVHQ"
    "WEJKSNPFAORYUICGBXZMLVHQWEJKSNPFAORYUIC"
)

print()
print("  Initializing sequence analysis...")
time.sleep(1)
print()

chunk_size = 40
for i in range(0, len(data), chunk_size):
    chunk = data[i:i+chunk_size]
    print(f"  [{i:04d}] {chunk}")
    time.sleep(0.08)

print()
time.sleep(1)
print("  Analysis complete.")
time.sleep(1)
print()
print("  There is a pattern here.")
time.sleep(1.5)
print()
print("  Not every character matters.")
time.sleep(1.5)
print()
print("  Only the ones at very specific positions.")
time.sleep(1.5)
print()
print("  Think mathematically.")
time.sleep(2)
print()

input("  Press Enter to close.")
