import time

def slow_print(text, delay=0.04):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

print()
slow_print("  Initializing transmission...", 0.04)
time.sleep(1)
print()
slow_print("  Incoming signal detected.", 0.04)
time.sleep(1.5)
print()
slow_print("  Decoding...", 0.04)
time.sleep(2)
print()
print("  " + "─" * 25)
print()

morse = ".  ...-  .  -.  ..  -.  --."
for char in morse:
    if char == '.':
        print(".", end='', flush=True)
        time.sleep(0.3)
    elif char == '-':
        print("-", end='', flush=True)
        time.sleep(0.3)
    elif char == ' ':
        print(" ", end='', flush=True)
        time.sleep(0.1)

print()
print()
print("  " + "─" * 25)
print()
time.sleep(1)
slow_print("  Transmission complete.", 0.04)
time.sleep(1)
print()
slow_print("  What does it say?", 0.04)
print()
input("  Press Enter to close.")
